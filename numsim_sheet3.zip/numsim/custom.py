visu = 1 # do build a debug visualization
# visu = 0 # do not build a debug visualization
