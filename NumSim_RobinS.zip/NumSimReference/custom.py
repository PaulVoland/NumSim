visu = 1 # do build a debug visualization
vtk = 1
