#include "geometry.hpp"
#include "iterator.hpp"
#include "grid.hpp"
#include "typedef.hpp"
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>

using namespace std;

Geometry::Geometry() {

    cout << "Geometry initialisiert" << endl;
    // const char file[] = "default.geom";
    const char file[] = "test.geom";
    // const char file[] = "../test.geom";
    Load(file);
    cout << "Geometry geladen" << endl;

    // Mesh-Size
    this->_h[0] = this->_length[0]/this->_size[0];
    this->_h[1] = this->_length[1]/this->_size[1];
    //Adding Ghost Cells
    this->_size[0] = this->_size[0] + 2;
    this->_size[1] = this->_size[1] + 2;
    cout << "Geometry zugewiesen" << endl;
}

void Geometry::Load(const char *file){
    FILE* handle = fopen(file,"r");
    double inval[2];
    char name[20];
    while (!feof(handle)) {
        if (!fscanf(handle, "%s =", name)) continue;
        if (strcmp(name,"size") == 0) {
            if (fscanf(handle," %lf %lf\n",&inval[0],&inval[1])) {
                this->_size[0] = inval[0];
                this->_size[1] = inval[1];
            }
            continue;
        }
        if (strcmp(name,"length") == 0) {
            if (fscanf(handle," %lf %lf\n",&inval[0],&inval[1])) {
                this->_length[0] = inval[0];
                this->_length[1] = inval[1];
            }
            continue;
        }
        if (strcmp(name,"velocity") == 0) {
            if (fscanf(handle," %lf %lf\n",&inval[0],&inval[1])) {
                this->_velocity[0] = inval[0];
                this->_velocity[1] = inval[1];
            }
            continue;
        }
        if (strcmp(name,"pressure") == 0) {
            if (fscanf(handle," %lf\n",&inval[0]))
                this->_pressure = inval[0];
            continue;
        }
    }
    fclose(handle);
}


/// Returns the number of cells in each dimension
const multi_index_t &Geometry::Size() const{
    return _size;
}
/// Returns the length of the domain
const multi_real_t &Geometry::Length() const{
    return _length;
}
/// Returns the meshwidth
const multi_real_t &Geometry::Mesh() const{
    return _h;
}
/// Returns the velocity
const multi_real_t &Geometry::Velocity() const{
    return _velocity;
}

/// Updates the velocity field u
void Geometry::Update_U(Grid *u) const{
    BoundaryIterator boundi(this,'u');
    for(index_t b = 0; b <= 3; b++){
        boundi.SetBoundary(b);
        boundi.Next();
        for(boundi;boundi.Valid();boundi.Next()){
            switch(b){
                case 0:
                    u->Cell(boundi) = -(u->Cell(boundi.Top()));
                    break;
                case 1:
                    u->Cell(boundi.Left()) = this->_velocity[1];
                    u->Cell(boundi) = this->_velocity[1];
                    break;
                case 2:
                    u->Cell(boundi) = 2*this->_velocity[0] - u->Cell(boundi.Down());
                    break;
                case 3:
                    u->Cell(boundi) = this->_velocity[1];
                    break;
            }
        }
    } 
    // u->Cell(Iterator(this,this->Size()[0]*this->Size()[1]-this->Size()[0])) = _velocity[0];
}    
/// Updates the velocity field v
void Geometry::Update_V(Grid *v) const{
    BoundaryIterator boundi(this,'v');
    for(index_t b = 0; b <= 3; b++){
        boundi.SetBoundary(b);
        boundi.Next();
        for(boundi;boundi.Valid();boundi.Next()){
            switch(b){
                case 0:
                    v->Cell(boundi) = this->_velocity[1];
                    break;
                case 1:
                    v->Cell(boundi) = -(v->Cell(boundi.Left()));
                    break;
                case 2:
                    v->Cell(boundi.Down()) = this->_velocity[1];
                    v->Cell(boundi) = this->_velocity[1];
                    break;
                case 3:
                    v->Cell(boundi) = -(v->Cell(boundi.Right()));
                    break;
            }
        }
    } 
}
/// Updates the pressure field p
void Geometry::Update_P(Grid *p) const{
    BoundaryIterator boundi(this,'p');
    for(index_t b = 0; b <= 3; b++){
        boundi.SetBoundary(b);
        boundi.Next();
        for(boundi;boundi.Valid();boundi.Next()){
            switch(b){
                case 0:
                    p->Cell(boundi) = p->Cell(boundi.Top());
                    break;
                case 1:
                    p->Cell(boundi) = p->Cell(boundi.Left());
                    break;
                case 2:
                    p->Cell(boundi) = p->Cell(boundi.Down());
                    break;
                case 3:
                    p->Cell(boundi) = p->Cell(boundi.Right());
                    break;
            }
        }
    } 
    // boundi.SetBoundary(0);
    // p->Cell(boundi) = p->Cell(boundi.Top());
}

// int main(int argc, char **argv) {
//     Geometry geom = Geometry();
//     Grid grid = Grid(&geom,0);
//     grid.Initialize(0);

//     cout << grid.AbsMax() << endl;

//     // geom.Update_U(&grid);
//     Iterator it = Iterator(&geom);
//     index_t y_val = 0;
//     // while(it.Valid()){
//     //     cout << grid.Cell(it) << " ";
//     //     it.Next();
//     //     if(it.Pos()[1] != y_val){
//     //         cout << endl;
//     //         y_val++;
//     //     }
//     // }
//     // cout << endl;
    
//     // geom.Update_V(&grid);
//     // it = Iterator(&geom);
//     // y_val = 0;
//     // while(it.Valid()){
//     //     cout << grid.Cell(it) << " ";
//     //     it.Next();
//     //     if(it.Pos()[1] != y_val){
//     //         cout << endl;
//     //         y_val++;
//     //     }
//     // }
//     // cout << endl;

//     geom.Update_P(&grid);
//     it = Iterator(&geom);
//     y_val = 0;
//     while(it.Valid()){
//         cout << grid.Cell(it) << " ";
//         it.Next();
//         if(it.Pos()[1] != y_val){
//             cout << endl;
//             y_val++;
//         }
//     }

//     // multi_real_t length = geom.Length();
//     // multi_index_t size = geom.Size();
//     // multi_real_t mesh = geom.Mesh();

//     // std::cout << length[0] << " und " << length[1] << std::endl; 
//     // std::cout << size[0] << " und " << size[1] << std::endl; 
//     // std::cout << mesh[0] << " und " << mesh[1] << std::endl; 

//     return 0;
// }