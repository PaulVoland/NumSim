#include "iterator.hpp"
#include "geometry.hpp"
#include <cmath>
#include <iostream>
#include "typedef.hpp"

using namespace std;

// class Iterator 
// Constructs a new Iterator depending on a geometry
Iterator::Iterator(const Geometry *geom){
    this->_geom = geom;
    this->_value = 0;
    this->_valid = true;
}
/// Constructs a new Iterator on a geometry with a defined starting value
Iterator::Iterator(const Geometry *geom, const index_t &value){
    this->_geom = geom;
    this->_value = value;
    this->_valid = true;

    if (this->_value >= (this->_geom->Size()[0])*(this->_geom->Size()[1])){
        this->_valid = false;
    }
}

///     Returns the current position value
const index_t &Iterator::Value() const{
    return _value; 
}
/// Cast operator to convert Iterators to integers
Iterator::operator const index_t &() const{
    return _value;
}
/// Returns the position coordinates
multi_index_t Iterator::Pos() const{
    multi_index_t position;
    position[0] = _value % (_geom->Size()[0]);
    position[1] = floor(_value/(_geom->Size()[0]));
    return position;
}

/// Sets the iterator to the first element
void Iterator::First(){
    this->_value = 0;
    this->_valid = true;
}
/// Goes to the next element of the iterator, disables it if position is end
void Iterator::Next(){
    if (this->_value < (this->_geom->Size()[0]*this->_geom->Size()[1])-1){
    // if (this->_value < (this->_geom->Size()[0]*this->_geom->Size()[1])){
        this->_value += 1;
        this->_valid = true;
    }else{
        this->_value += 1;
        this->_valid = false;
    }
}

/// Checks if the iterator still has a valid value
bool Iterator::Valid() const{
    return _valid;
}

/// Returns an Iterator that is located left from this one.
// if we are at the left boundary, the cell sees itself
Iterator Iterator::Left() const{
    // if (this->Pos()[0] != 0){
    if (_value % _geom->Size()[0] != 0){
        return Iterator(_geom,_value-1);
    }else{
        cout << "linker Rand erreicht" << endl;
        // return Iterator(this->_geom,this->_value);
        return *this;
    }
}

/// Returns an Iterator that is located right from this one
// If we are at the right boundary, the cell sees itself
Iterator Iterator::Right() const{
    // if (this->Pos()[0] != (this->_geom->Size()[0])-1){
    if (_value % _geom->Size()[0] != _geom->Size()[0] - 1){
        return Iterator(_geom,_value+1);
    }else{
        cout << "rechter Rand erreicht" << endl;
        // return Iterator(this->_geom,this->_value);
        return *this;
    }
}

/// Returns an Iterator that is located above this one
// If we are at the upper domain boundary, the cell sees itself
Iterator Iterator::Top() const{
    // if (this->Pos()[1]<_geom->Size()[1]-1){
    if (_value < _geom->Size()[0]*(_geom->Size()[1] - 1)){
        return Iterator(_geom,_value+_geom->Size()[0]);
    }else{
        cout << "oberer Rand erreicht" << endl;
        // return Iterator(this->_geom,this->_value);
        return *this;
    }
}

/// Returns an Iterator that is located below this one
// If we are at the lower domain boundary, the cell sees itself
Iterator Iterator::Down() const{
    // if (this->Pos()[1] > 0){
    if (_value >= _geom->Size()[0]){
        return Iterator(_geom,_value-_geom->Size()[0]);
    }else{
        cout << "unterer Rand erreicht" << endl;
        // return Iterator(this->_geom,this->_value);
        return *this;
    }
}

//------------------------------------------------------------------------------
/** Iterator for interior cells
*/
// class InteriorIterator : public Iterator {
  
/// Construct a new InteriorIterator
InteriorIterator::InteriorIterator(const Geometry *geom, const char gridIdent) : Iterator(geom){
    this->_value = this->_geom->Size()[0] + 1;
    this->_valid = true;
    this->_gridIdent = gridIdent;
    
    switch(this->_gridIdent){
        case 'u':
            _lastInterValueDownRight = this->_geom->Size()[0] - 3;
            _lastInterValueTopRight = this->_geom->Size()[0] * (this->_geom->Size()[1] - 1) - 3;
            // _lastInterValueTopLeft = this->_geom->Size()[0] * (this->_geom->Size()[1] - 2);
            _schrittNaechsteEbene = 4;
            break;
        case 'v':
            _lastInterValueDownRight = this->_geom->Size()[0] - 2;
            _lastInterValueTopRight = this->_geom->Size()[0] * (this->_geom->Size()[1] - 2) - 2;
            // _lastInterValueTopLeft = this->_geom->Size()[0] * (this->_geom->Size()[1] - 3);
            _schrittNaechsteEbene = 3;
            break;
        case 'p':
            _lastInterValueDownRight = this->_geom->Size()[0] - 2;
            _lastInterValueTopRight = this->_geom->Size()[0] * (this->_geom->Size()[1] - 1) - 2;
            // _lastInterValueTopLeft = this->_geom->Size()[0] * (this->_geom->Size()[1] - 2);
            _schrittNaechsteEbene = 3;
            break;
    }        
}

// /// Construct a new InteriorIterator
// InteriorIterator::InteriorIterator(const Geometry *geom) : Iterator(geom){
//     this->_value = this->_geom->Size()[0]+1;
//     this->_valid = true;
// }

/// Sets the iterator to the first element
void InteriorIterator::First(){
    this->_value = this->_geom->Size()[0] + 1;
    this->_valid = true;
}
/// Goes to the next element of the iterator, disables it if position is end
void InteriorIterator::Next(){
    if (this->Pos()[0] < _lastInterValueDownRight){
        _value += 1;
        _valid = true;
    }else if ((this->Pos()[0] == _lastInterValueDownRight)){
        if(this->_value < _lastInterValueTopRight){
            this->_value += _schrittNaechsteEbene;
            this->_valid = true;
        }else{
            this->_valid = false;
        }
    }

    // if (this->Pos()[0] < this->_geom->Size()[0]-2){
    //     _value++;
    //     _valid = true;
    // }else if((this->Pos()[0] == this->_geom->Size()[0]-2) && (this->Pos()[1] < this->_geom->Size()[1]-2)){
    //     this->_value += 3;
    //     this->_valid = true;
    // }else{
    //     this->_valid = false;
    // }
}

// //------------------------------------------------------------------------------
// // InteriorIterator
// // Constructor requires a char varibale to determine the boundary area
// // Use 'u' if u, 'v' if v, 'p' if p
// InteriorIterator::InteriorIterator(const Geometry *geom, const char var):
//     Iterator(geom)

// {
//     _value = _geom->Size()[0] + 1;
//     _var = var;
//     _counter = 1;
//     if(_var == 'u'){_border = _geom->Size()[0] - 3;}
//     else{_border = _geom->Size()[0] - 2;}
//     switch(_var){
//     case 'u':
//         _steppingStone = _geom->Size()[0]*(_geom->Size()[1] - 1) - 3;
//         break;
//     case 'v':
//         _steppingStone = _geom->Size()[0]*(_geom->Size()[1] - 2) - 2;
//         break;
//     case 'p':
//         _steppingStone = _geom->Size()[0]*(_geom->Size()[1] - 1) - 2;
//         break;
//     }
// }

// // InteriorIterator's First resets its value to the bottom left interior(!) cell and the boolean to true
// void InteriorIterator::First(){
//     _valid = true;
//     _value = _geom->Size()[0] + 1;
//     _counter = 1;
// }

// // InteriorIterator's Next will run through all interior cells, these are those whose variables are NOT set
// // When reaching the last cell the boolean will be set to false
// // The counter is helper variable used to measure the distance to the boundary
// void InteriorIterator::Next(){
//     if(_value == _steppingStone){_valid = false;}
//     if(_counter < _border){
//         _value += 1;
//         _counter += 1;
//     }else{
//         _value += (_geom->Size()[0] - _border) + 1;
//         _counter = 1;
//     }
// }






//------------------------------------------------------------------------------
/** Iterator for domain boundary cells.
*/
// class BoundaryIterator : public Iterator {

/// Constructs a new BoundaryIterator
BoundaryIterator::BoundaryIterator(const Geometry *geom, const char gridIdent) : Iterator(geom){
    this->_boundary = 0;
    this->_gridIdent = gridIdent;

    switch(this->_gridIdent){
        case 'u':
            _leftDownCorner = 0;
            _rightDownCorner = this->_geom->Size()[0] - 2;
            _rightTopCorner = this->_geom->Size()[0] * (this->_geom->Size()[1]) - 2;
            _leftTopCorner = this->_geom->Size()[0] * (this->_geom->Size()[1] - 1);
            break;
        case 'v':
            _leftDownCorner = 0;
            _rightDownCorner = this->_geom->Size()[0] - 1;
            _rightTopCorner = this->_geom->Size()[0] * (this->_geom->Size()[1] - 1) - 1;
            _leftTopCorner = this->_geom->Size()[0] * (this->_geom->Size()[1] - 2);
            break;
        case 'p':
            _leftDownCorner = 0;
            _rightDownCorner = this->_geom->Size()[0] - 1;
            _rightTopCorner = this->_geom->Size()[0] * (this->_geom->Size()[1]) - 1;
            _leftTopCorner = this->_geom->Size()[0] * (this->_geom->Size()[1] - 1);
            break;
    }  
}

/// Sets the boundary to iterate
void BoundaryIterator::SetBoundary(const index_t &boundary){
    this->_boundary = boundary; 
    switch(this->_boundary){
        case 0: //unten
            this->_value = this->_leftDownCorner;
            this->_valid = true;
            break;
        case 1: //rechts
            this->_value = this->_rightDownCorner;
            this->_valid = true;
            break;
        case 2: //oben
            this->_value = this->_rightTopCorner;
            this->_valid = true;
            break;
        case 3: //links
            this->_value = this->_leftTopCorner;
            this->_valid = true;
            break;
    }
}

/// Sets the iterator to the first element
void BoundaryIterator::First(){
    _valid = true;
    _value = _leftDownCorner;
    _boundary = 0;
}
/// Goes to the next element of the iterator, disables it if position is end
void BoundaryIterator::Next(){
    switch(_boundary){
        case 0:
            if (_value < _rightDownCorner){
                _value += 1;
                _valid = true;
            }else{
                // this->SetBoundary(1);
                _valid = false;
            }
            break;
        case 1:
            if (_value < _rightTopCorner){
                _value = this->Top().Value();
                _valid = true;
            }else{
                // this->SetBoundary(2);
                _valid = false;
            }
            break;
        case 2:
            if (_value > _leftTopCorner){
                _value -= 1;
                _valid = true;
            }else{
                // this->SetBoundary(3);
                _valid = false;
            }
            break;
        case 3:
            if (_value > _leftDownCorner){
                _value = this->Down().Value();
                _valid = true;
            }else{
                // this->SetBoundary(0);
                _valid = false;
            }
            break;
    }

//     if ((Iterator::Pos()[0] < _geom->Size()[1]-1) && (Iterator::Pos()[1] == 0)){
//         _value += 1;
//         _valid = true;
//     }else if((Iterator::Pos()[0] > 0) && (Iterator::Pos()[1] == _geom->Size()[1]-1)){
//         _value -= 1;
//         _valid = true;
//     }else if((Iterator::Pos()[0] == _geom->Size()[0]-1) && (Iterator::Pos()[1]<_geom->Size()[1]-1)){
//         _value = Iterator::Top().Value();
//         _valid = true;
//     }else if((Iterator::Pos()[0] == 0) && (Iterator::Pos()[1]>1)){
//         _value = Iterator::Down().Value();
//         _valid = true;
//     }else{
//         _valid = false;
//     } 
}




// //------------------------------------------------------------------------------
// // BoundaryIterator
// // Constructor requires a char varibale to determine the boundary area
// // Use 'u' if u, 'v' if v, 'p' if p
// BoundaryIterator::BoundaryIterator(const Geometry *geom, const char var):
//     Iterator(geom)

// {
//     _boundary = 0;
//     _steppingStone = _geom->Size()[0];
//     _var = var;
//     /// Initilazie corners of the boundary rectangle
//     //  lower Corners
//     _lowerLeftCorner = 0;
//     if(_var == 'u'){_lowerRightCorner = _geom->Size()[0] - 2;}
//     else _lowerRightCorner = _geom->Size()[0] - 1;
//     //  upper Corners
//     switch(_var){
//         case 'u':
//             _upperRightCorner = _geom->Size()[0]*_geom->Size()[1] - 2;
//             break;
//         case 'v':
//             _upperRightCorner = _geom->Size()[0]*(_geom->Size()[1] - 1) - 1;
//             break;
//         case 'p':
//             _upperRightCorner = _geom->Size()[0]*_geom->Size()[1] - 1;
//             break;
//     }
//     if(_var == 'v'){_upperLeftCorner = _geom->Size()[0]*(_geom->Size()[1] - 2);}
//     else _upperLeftCorner = _geom->Size()[0]*(_geom->Size()[1] - 1);
// }

// // Considering the counterclockwise rotation the Next method perfroms, SetBoundary sets the value to the beginning of an edge of an rectangular
// // simulation area an resets the boolean value to true
// // The index_t parameter refers to 0 if 'bottom', 1 if 'right', 2 if 'top', 3 if 'left'
// void BoundaryIterator::SetBoundary(const index_t &boundary) {
//     _valid = true;
//     _boundary = boundary;
//     switch(_boundary){
//         case 0:
//             _value = _lowerLeftCorner;
//             _steppingStone = _value + _geom->Size()[0];
//             break;
//         case 1:
//             _value = _lowerRightCorner;
//             _steppingStone = _value - 1;
//             break;
//         case 2:
//             _value = _upperRightCorner;
//             _steppingStone = _value - _geom->Size()[0];
//             break;
//         case 3:
//             _value = _upperLeftCorner;
//             _steppingStone = _value + 1;
//             break;
//         default:
//             cout << "Please enter: 0 if 'bottom', 1 if 'right', 2 if 'top', 3 if 'left'" << endl;
//             break;
//     }
// }

// // First resets the BoundaryIterator's value to the zero-cell, its boolean to true and the boundary to 0 conferring to 'bottom'
// void BoundaryIterator::First(){
//     _valid = true;
//     _value = _lowerLeftCorner;
//     _boundary = 0;
//     _steppingStone = _value + _geom->Size()[0];
// }

// // Next will run once counterclockwise through every cell of the boundary area of the simulation area
// // When finished the BoundaryIterators boolean will be set to false
// void BoundaryIterator::Next(){
//     // when reaching the last cell in one rotation, whose value is saved in stepping stone flip the BoundaryIterator's boolean to false
//     if(_value == _steppingStone){_valid = false;}
//     switch(_boundary){
//         // increasing the value by one equals moving to the right applied when the boundary is 0 representing 'bottom'
//         case 0:
//             if(_value < _lowerRightCorner){_value += 1;}
//             else{
//                 _boundary = 1;
//                 _value += _geom->Size()[0];
//                 _valid = false;
//             }
//             break;
//         // increasing the value by one grid width equals moving to the top applied when the boundary is 1 representing 'right'
//         case 1:
//             if(_value < _upperRightCorner){_value += _geom->Size()[0];}
//             else{
//                 _boundary = 2;
//                 _value -= 1;
//                 _valid = false;
//             }
//             break;
//         // decreasing the value by one equals moving to the left applied when the boundary is 2 representing 'top'
//         case 2:
//             if(_value > _upperLeftCorner){_value -= 1;}
//             else{
//                 _boundary = 3;
//                 _value -= _geom->Size()[0];
//                 _valid = false;
//             }
//             break;
//         // decreasing the value by one grid width equals moving down applied when the boundary is 3 representing 'left'
//         case 3:
//             if(_value > _lowerLeftCorner){_value -= _geom->Size()[0];}
//             else{
//                 _boundary = 0;
//                 _value += 1;
//                 _valid = false;
//             }
//             break;
//     }
// }

// index_t& BoundaryIterator::GetBoundary() {return _boundary;}








// int main(int argc, char **argv) {
//     const Geometry *geom = new Geometry();
//     // Iterator iter = Iterator(geom);
//     // while (iter.Valid()){
//     //     cout << iter.Value() << " ";
//     //     iter.Next();
//     // }
//     // cout << endl;
//     // iter.First();
//     // cout << iter.Value() << " " << endl;

//     BoundaryIterator inti = BoundaryIterator(geom);
//     inti.SetBoundary(3);
//     while (inti.Valid()){
//         cout << inti.Value() << " ";
//         inti.Next();
//     }
//     cout << endl;
//     inti.First();
//     cout << inti.Value() << " " << endl;

//     return 0;
// }