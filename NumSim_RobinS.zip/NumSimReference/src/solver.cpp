#include "solver.hpp"
#include "geometry.hpp"
#include "iterator.hpp"
#include "grid.hpp"
#include <cmath>
#include <iostream>
#include "typedef.hpp"

using namespace std;

/// Constructor of the abstract Solver class
Solver::Solver(const Geometry *geom){
    this->_geom = geom;
}
/// Destructor of the Solver Class
Solver::~Solver(){
}

/// Returns the residual at [it] for the pressure-Poisson equation
real_t Solver::localRes(const Iterator &it, const Grid *grid, const Grid *rhs) const{
    return fabs(rhs->Cell(it) - (grid->dxx(it) + grid->dyy(it)));
}

/// Constructs an actual SOR solver
SOR::SOR(const Geometry *geom, const real_t &omega) : Solver(geom){
    this->_geom = geom;
    this->_omega = omega;
}
/// Destructor
SOR::~SOR(){
}

/// Returns the total residual and executes a solver cycle
// @param grid current pressure values
// @param rhs right hand side
real_t SOR::Cycle(Grid *grid, const Grid *rhs) const{
    real_t dx = this->_geom->Mesh()[0];
    real_t dy = this->_geom->Mesh()[1];

    real_t gain = (dx*dx*dy*dy)/(2.0*(dx*dx+dy*dy));

    real_t residuum = 0;

    // cout << "in P" << endl;
    for(InteriorIterator it(this->_geom,'p');it.Valid();it.Next()){
        // cout << "P Berechnung" << endl;
        real_t pij = grid->Cell(it);
        real_t pijLeft = grid->Cell(it.Left());
        real_t pijRight = grid->Cell(it.Right());
        real_t pijDown = grid->Cell(it.Down());
        real_t pijTop = grid->Cell(it.Top());

        real_t calcu = (pijLeft+pijRight)/(dx*dx) + (pijDown+pijTop)/(dy*dy) - rhs->Cell(it);

        grid->Cell(it) = (1.0 - this->_omega) * pij + this->_omega * gain * calcu;

        // local Residuum
        residuum += this->localRes(it,grid,rhs);
        // cout << residuum << endl;
    }
    // cout << "nach P: " << residuum << endl;
    return residuum;
}

// int main(int argc, char **argv) {
//     const Geometry *geom = new Geometry();
//     Iterator iter = Iterator(geom,12);
//     BoundaryIterator boundi = BoundaryIterator(geom);
//     boundi.SetBoundary(3);
//     InteriorIterator inti = InteriorIterator(geom);
//     Grid grid = Grid(geom,0);
//     grid.Initialize(0);
//     Grid rhs = Grid(geom,0);
//     rhs.Initialize(0);
    
//     index_t step = 0;

//     // while (iter.Valid()){
//     //     cout << grid.Cell(iter)+step << endl ;  
//     //     iter.Next();
//     //     step +=1;
//     // }
//     // cout << "Jetzt kommt boundi" << endl;
//     // step = 0;
//     // while (boundi.Valid()){
//     //     cout << grid.Cell(boundi)+step << endl ;  
//     //     boundi.Next();
//     //     step +=1;
//     // }
//     // cout << "Jetzt kommt inti" << endl;
//     // step = 0;
//     // while (inti.Valid()){
//     //     cout << grid.Cell(inti)+step << endl ;  
//     //     inti.Next();
//     //     step +=1;
//     // }

//     grid.Cell(iter) = 1;
//     real_t pi = 3.14159265358979323846;
//     real_t omega = 2/(1+sin(pi*geom->Mesh()[0]));
//     SOR sor = SOR(geom,omega);

//     real_t resi = 100;
//     cout << "Residuum: " << resi << "   Value: " << grid.Cell(iter) << endl;

//     while(resi>1e-8){
//         resi = sor.Cycle(&grid,&rhs);
//         cout << "Residuum: " << resi << "   Value: " << grid.Cell(iter) << endl;
//     }
//     cout << "anderer Value: " << grid.Cell(iter.Top()) << endl << grid.Cell(iter.Left().Left()) << endl;
// }