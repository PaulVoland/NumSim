#include "compute.hpp"
#include "solver.hpp"
#include "geometry.hpp"
#include "iterator.hpp"
#include "grid.hpp"
#include "parameter.hpp"
#include <cmath>
#include <iostream>
#include "typedef.hpp"

using namespace std;

/// Creates a compute instance with given geometry and parameter
Compute::Compute(const Geometry *geom, const Parameter *param){
    this->_geom = geom;
    this->_param = param;

    // this->_dtlimit = 0;
    // this->_epslimit = 0;
    
    multi_real_t u_offset;
    u_offset[0] = this->_geom->Mesh()[0];
    u_offset[1] = this->_geom->Mesh()[1]/2.0;

    multi_real_t v_offset;
    v_offset[0] = this->_geom->Mesh()[0]/2.0;
    v_offset[1] = this->_geom->Mesh()[1];

    multi_real_t p_offset;
    p_offset[0] = this->_geom->Mesh()[0]/2.0;
    p_offset[1] = this->_geom->Mesh()[1]/2.0;

    multi_real_t absVel_offset;
    absVel_offset[0] = this->_geom->Mesh()[0]/2.0;
    absVel_offset[1] = this->_geom->Mesh()[1]/2.0;

    // this->_u = new Grid(this->_geom, absVel_offset);
    // this->_v = new Grid(this->_geom, absVel_offset);
    // this->_F = new Grid(this->_geom, absVel_offset);
    // this->_G = new Grid(this->_geom, absVel_offset);

    this->_u = new Grid(this->_geom, u_offset);
    this->_v = new Grid(this->_geom, v_offset);
    this->_F = new Grid(this->_geom, u_offset);
    this->_G = new Grid(this->_geom, v_offset);
    this->_absVel = new Grid(this->_geom, absVel_offset);
    this->_p = new Grid(this->_geom, p_offset);
    this->_rhs = new Grid(this->_geom, p_offset);
    this->_tmp = new Grid(this->_geom);

    this->_u->Initialize(0.0);
    this->_v->Initialize(0.0);
    this->_absVel->Initialize(0.0);
    this->_p->Initialize(0.1);
    this->_F->Initialize(0.0);
    this->_G->Initialize(0.0);
    this->_rhs->Initialize(0.0);
    this->_tmp->Initialize(0.0);

    this->_solver = new SOR(this->_geom, this->_param->Omega());

    cout << "compute initialisiert" << endl;

    // blub = true;

    // if(blub){
    // for(index_t i = 0; i<this->_geom->Size()[0]*this->_geom->Size()[1]; i++){
    //     cout << _u->Data()[i] << " ";
    // }blub=false;}

    _t = 0;
}
/// Deletes all grids
Compute::~Compute(){
    delete _u;
    delete _v;
    delete _absVel;
    delete _p;
    delete _F;
    delete _G;
    delete _tmp;
    delete _rhs;
}

/// Execute one time step of the fluid simulation (with or without debug info)
// @ param printInfo print information about current solver state (residual
// etc.)
void Compute::TimeStep(bool printInfo){
    real_t dt;

    // // Randwerte setzen
    // this->_geom->Update_U(this->_u);
    // this->_geom->Update_V(this->_v);
    // this->_geom->Update_P(this->_p);

    real_t dx = this->_geom->Mesh()[0];
    real_t dy = this->_geom->Mesh()[1];

    real_t dt_diffusionStab = 0.5 * this->_param->Re() * (dx * dx * dy * dy) / (dx * dx + dy * dy);

    // if(blub){
    // for(index_t i = 0; i<this->_geom->Size()[0]*this->_geom->Size()[1]; i++){
    //     // if(abs(_u->Data()[i]) > tempAbs){
    //         // tempAbs = abs(this->_data[i]);
    //     // }
    //     cout << _u->Data()[i] << " ";
    // }blub=false;}

    real_t dt_convecX = dx / this->_u->AbsMax();
    real_t dt_convecY = dy / this->_v->AbsMax();

    real_t dt_min = min(dt_diffusionStab,min(dt_convecX,dt_convecY));

    // if (printInfo){
    //     cout << "dt_min = " << dt_min << " , dt_convecX = " << dt_convecX << " , dt_convecY = " << dt_convecY << " , dt_diffusionStab = " << dt_diffusionStab << endl;
    //     cout << "v_absmax = " << _v->AbsMax() << " , u_absmax = " << _u->AbsMax() << endl;
    // }

    if(dt_min < this->_param->Dt()){
        // if (printInfo){
        //     cout << "Fehler: Neue Zeitschrittweite dt = " << dt_min << " , da Stabilitaetskriterium verletzt war." << endl;
        // }
        dt = dt_min;
    }else{
        dt = this->_param->Dt();
    }

    // Randwerte setzen
    this->_geom->Update_U(this->_u);
    this->_geom->Update_V(this->_v);
    this->_geom->Update_P(this->_p);

    // Berechnung von F und G
    this->MomentumEqu(dt);

    // Rechte Seite
    this->RHS(dt);

    // Mit SOR Poissonsgleichung loesen
    index_t iteration = 1;
    real_t residuum = 100;

    while(iteration <= this->_param->IterMax() && residuum > this->_param->Eps()){
        // this->_geom->Update_P(this->_p);
        residuum = _solver->Cycle(this->_p,this->_rhs);
        this->_geom->Update_P(this->_p);
        iteration++;
        // cout << "residuum: " << residuum << endl;
    }
    

    // Berechne endgueltige Geschwindigkeit
    this->NewVelocities(dt);

    // this->_geom->Update_U(this->_u);
    // this->_geom->Update_V(this->_v);
    
    this->_t += dt;

    // cout << "dt_convecX: " << dt_convecX << endl;
    // cout << "dt_convecY: " << dt_convecY << endl;
    // cout << "dt_diffusionStab: " << dt_diffusionStab << endl;
    // cout << "Zeitschritt: " << this->_t << endl;

    if (printInfo){
        cout << "t = " << _t << " , Residuum = " << residuum << endl;
    }
}

/// Returns the simulated time in total
const real_t &Compute::GetTime() const{
    return _t;
}

/// Returns the pointer to U
const Grid *Compute::GetU() const{
    return _u;
}
/// Returns the pointer to V
const Grid *Compute::GetV() const{
    return _v;
}
/// Returns the pointer to P
const Grid *Compute::GetP() const{
    return _p;
}
/// Returns the pointer to RHS
const Grid *Compute::GetRHS() const{
    return _rhs;
}

/// Computes and returns the absolute velocity
const Grid *Compute::GetVelocity(){
    // Absolutgeschwindigkeit im Mittelpunkt
    for(InteriorIterator inti(this->_geom,'p');inti.Valid();inti.Next()){
        real_t u_mitte = (this->_u->Cell(inti)+this->_u->Cell(inti.Left())) / 2.0;
        real_t v_mitte = (this->_v->Cell(inti)+this->_v->Cell(inti.Down())) / 2.0;
        this->_absVel->Cell(inti) = sqrt(u_mitte*u_mitte + v_mitte*v_mitte);   
    }

    real_t absVelInital = sqrt(this->_geom->Velocity()[0]*this->_geom->Velocity()[0] + this->_geom->Velocity()[1]*this->_geom->Velocity()[1]);

    BoundaryIterator boundi(this->_geom,'p');
    for(index_t b = 0; b <= 3; b++){
        boundi.SetBoundary(b);

        boundi.Next();

        for(boundi;boundi.Valid();boundi.Next()){
            switch(b){
                case 0:
                    this->_absVel->Cell(boundi) = -(this->_absVel->Cell(boundi.Top()));
                    break;
                case 1:
                    this->_absVel->Cell(boundi) = -(this->_absVel->Cell(boundi.Left()));
                    break;
                case 2:
                    this->_absVel->Cell(boundi) = 2*absVelInital - this->_absVel->Cell(boundi.Down());
                    break;
                case 3:
                    this->_absVel->Cell(boundi) = -(this->_absVel->Cell(boundi.Right()));
                    break;
            }
        }
    } 
    // Iterator itCrap = Iterator(this->_geom);
    // index_t y_val = 0;
    // while(itCrap.Valid()){
    //     cout << _absVel->Cell(itCrap) << " ";
    //     itCrap.Next();
    //     if(itCrap.Pos()[1] != y_val){
    //         cout << endl;
    //         y_val++;
    //     }
    // }
    // cout << endl;

    return _absVel;
}
/// Computes and returns the vorticity
const Grid *Compute::GetVorticity(){
    return _tmp;
}
/// Computes and returns the stream line values
const Grid *Compute::GetStream(){
    return _tmp;
}

/// Compute the new velocites u,v
void Compute::NewVelocities(const real_t &dt){
    for(InteriorIterator inti(this->_geom,'u');inti.Valid();inti.Next()){
        this->_u->Cell(inti) = this->_F->Cell(inti) - dt * this->_p->dx_r(inti); 
    }
    for(InteriorIterator inti(this->_geom,'v');inti.Valid();inti.Next()){
        this->_v->Cell(inti) = this->_G->Cell(inti) - dt * this->_p->dy_r(inti); 
    }
}
/// Compute the temporary velocites F,G
void Compute::MomentumEqu(const real_t &dt){
    for(InteriorIterator inti(this->_geom,'u');inti.Valid();inti.Next()){
        real_t A = 1.0 / (this->_param->Re()) * (this->_u->dxx(inti) + this->_u->dyy(inti)) - 
                    this->_u->DC_udu_x(inti,this->_param->Alpha()) - this->_u->DC_vdu_y(inti,this->_param->Alpha(),this->_v); 
        this->_F->Cell(inti) = this->_u->Cell(inti) + dt * A;
    }
    this->_geom->Update_U(this->_F);

    for(InteriorIterator inti(this->_geom,'v');inti.Valid();inti.Next()){
        real_t B = 1.0 / (this->_param->Re()) * (this->_v->dxx(inti) + this->_v->dyy(inti)) - 
                    this->_v->DC_udv_x(inti,this->_param->Alpha(),this->_u) - this->_v->DC_vdv_y(inti,this->_param->Alpha());
        this->_G->Cell(inti) = this->_v->Cell(inti) + dt * B;
    }
    this->_geom->Update_V(this->_G);
}
/// Compute the RHS of the poisson equation
void Compute::RHS(const real_t &dt){
    for(InteriorIterator inti(this->_geom,'p');inti.Valid();inti.Next()){
        this->_rhs->Cell(inti) = ((this->_F->Cell(inti) - this->_F->Cell(inti.Left()))/this->_geom->Mesh()[0]
                                + (this->_G->Cell(inti) - this->_G->Cell(inti.Down()))/this->_geom->Mesh()[1])/dt;
    }
}