#include "grid.hpp"
#include "geometry.hpp"
#include "iterator.hpp"
#include <math.h>
#include <iostream>
using namespace std;

/// Constructs a grid based on a geometry
Grid::Grid(const Geometry *geom){
    this->_geom = geom;
    this->_offset = 0;
    this->_data = nullptr;
    this->_data = new real_t[this->_geom->Size()[0]*this->_geom->Size()[1]];
}

/// Constructs a grid based on a geometry with an offset
// @param geom   Geometry information
// @param offset distance of staggered grid point to cell's anchor point;
//               (anchor point = lower left corner)
Grid::Grid(const Geometry *geom, const multi_real_t &offset){
    // _data = nullptr;
    this->_geom = geom;
    this->_offset = offset;
    this->_data = new real_t[this->_geom->Size()[0]*this->_geom->Size()[1]];
}

/// Deletes the grid
Grid::~Grid(){
    delete[] _data;    
}

///     Initializes the grid with a value
void Grid::Initialize(const real_t &value){
    for(index_t i = 0; i<this->_geom->Size()[0]*this->_geom->Size()[1]; i++){
        this->_data[i] = value;
    }
}

/// Write access to the grid cell at position [it]
real_t &Grid::Cell(const Iterator &it){
    return _data[it];
}
/// Read access to the grid cell at position [it]
const real_t &Grid::Cell(const Iterator &it) const{
    return _data[it];
}

/// Interpolate the value at a arbitrary position
real_t Grid::Interpolate(const multi_real_t &pos) const{
    
    // // multi_real_t blockLeftCorner;
    // multi_real_t localLeftCorner;
    // // localLeftCorner[0] = pos[0] - _offset[0];
    // // localLeftCorner[1] = pos[1] - _offset[1];
    // multi_real_t posOhneOffset;
    // posOhneOffset[0] = max(pos[0] - this->_offset[0],0.0);
    // posOhneOffset[1] = max(pos[1] - this->_offset[1],0.0);

    // localLeftCorner[0] = floor(posOhneOffset[0]/this->_geom->Mesh()[0]);
    // localLeftCorner[1] = floor(posOhneOffset[1]/this->_geom->Mesh()[1]);

    // real_t localLeftValue = this->_geom->Size()[0]*localLeftCorner[1] + localLeftCorner[0];
    // Iterator it = Iterator(this->_geom, localLeftValue);

    // return _data[it];

    // real_t localLeftValue = _geom->Size()[0]*localLeftCorner[1] + localLeftCorner[0];
    
    // Iterator::Iterator it = Iterator(_geom, localLeftValue);

    // if(_offset[0] <= _geom->Mesh()[0]/2){
    //     // wir muessen links hin
    //     it = it.Left();

    //     if(_offset[1] <= _geom->Mesh()[1]/2){ // linke untere Haelfte
    //         // wir muessen nach unten
    //         it = it.Down();
    //     }
    //     //else: keine Aenderung
    // }else{
    //     // keine Aenderung
    //     if(_offset[1] <= _geom->Mesh()[1]/2){ // linke untere Haelfte
    //         // wir muessen nach unten
    //         it = it.Down();
    //     }
    //     //else: keine Aenderung
    // }
    // blockLeftCorner = it.Pos();

        // declaration of variables
    real_t interVal = 0.0;
    multi_real_t noOffsetPos;
    multi_real_t remainder;
    multi_index_t posCellIndex;

    // calculates the cell index for pos
    noOffsetPos[0] = pos[0] - _offset[0] + _geom->Mesh()[0];
    noOffsetPos[1] = pos[1] - _offset[1] + _geom->Mesh()[1];
    remainder[0] = fmod(noOffsetPos[0],_geom->Mesh()[0])/_geom->Mesh()[0];
    remainder[1] = fmod(noOffsetPos[1],_geom->Mesh()[1])/_geom->Mesh()[1];
    posCellIndex[0] = floor(noOffsetPos[0]/_geom->Mesh()[0]);
    posCellIndex[1] = floor(noOffsetPos[1]/_geom->Mesh()[1]);

    index_t it = posCellIndex[0]+posCellIndex[1]*_geom->Size()[0];

    // bilinear interpolation
    Iterator It(_geom,it);
    interVal += this->Cell(It)*(1-remainder[0])*(1-remainder[1]);
    interVal += this->Cell(It.Right())*(remainder[0])*(1-remainder[1]);
    interVal += this->Cell(It.Right().Top())*(remainder[0])*(remainder[1]);
    interVal += this->Cell(It.Top())*(1-remainder[0])*(remainder[1]);

    return interVal;

}

/// Computes the left-sided difference quatient in x-dim at [it]
real_t Grid::dx_l(const Iterator &it) const{
    return (this->Cell(it) - this->Cell(it.Left()))/this->_geom->Mesh()[0];
}
/// Computes the right-sided difference quatient in x-dim at [it]
real_t Grid::dx_r(const Iterator &it) const{
    return (this->Cell(it.Right()) - this->Cell(it))/this->_geom->Mesh()[0];
}
/// Computes the left-sided difference quatient in y-dim at [it]
real_t Grid::dy_l(const Iterator &it) const{
    return (this->Cell(it) - this->Cell(it.Down()))/this->_geom->Mesh()[1];
}
/// Computes the right-sided difference quatient in y-dim at [it]
real_t Grid::dy_r(const Iterator &it) const{
    return (this->Cell(it.Top()) - this->Cell(it))/this->_geom->Mesh()[1];
}
/// Computes the central difference quatient of 2nd order in x-dim at [it]
real_t Grid::dxx(const Iterator &it) const{
    return (this->Cell(it.Left()) - 2*this->Cell(it) + this->Cell(it.Right()))/(this->_geom->Mesh()[0]*this->_geom->Mesh()[0]);
}
/// Computes the central difference quatient of 2nd order in y-dim at [it]
real_t Grid::dyy(const Iterator &it) const{
    return (this->Cell(it.Top()) - 2*this->Cell(it) + this->Cell(it.Down()))/(this->_geom->Mesh()[1]*this->_geom->Mesh()[1]);
}

/// Computes u*du/dx with the donor cell method
real_t Grid::DC_udu_x(const Iterator &it, const real_t &alpha) const{
        //urp = u_rechts_plus; urm = u_rechts_minus; ulp = u_links_plus; ulm = u_links_minus
        //brauchen wir die ganzen this?
    real_t urp = this->Cell(it) + this->Cell(it.Right()); 
    real_t urm = this->Cell(it) - this->Cell(it.Right());
    real_t ulp = this->Cell(it.Left()) + this->Cell(it);
    real_t ulm = this->Cell(it.Left()) - this->Cell(it);
    return ((urp*urp - ulp*ulp) + alpha*(fabs(urp)*urm - fabs(ulp)*ulm))/(4.0*this->_geom->Mesh()[0]);
}
/// Computes v*du/dy with the donor cell method
real_t Grid::DC_vdu_y(const Iterator &it, const real_t &alpha, const Grid *v) const{
    //vrp=v_rechts_plus; utp = u_top_plus; utm = u_top_minus; udp = u_down_plus
    //udm = u_down_minus; vrdp = v_rechts_down_plus
    real_t vrp = v->Cell(it) + v->Cell(it.Right());
    real_t utp = this->Cell(it) + this->Cell(it.Top());
    real_t utm = this->Cell(it) - this->Cell(it.Top());
    real_t vrdp = v->Cell(it.Down()) + v->Cell(it.Right().Down());
    real_t udp = this->Cell(it.Down()) + this->Cell(it);
    real_t udm = this->Cell(it.Down()) - this->Cell(it);
    return ((vrp*utp - vrdp*udp) + alpha*(fabs(vrp)*utm - fabs(vrdp)*udm))/(4.0*this->_geom->Mesh()[1]);
}
/// Computes u*dv/dx with the donor cell method
real_t Grid::DC_udv_x(const Iterator &it, const real_t &alpha, const Grid *u) const{
    //utp=u_top_plus; vrp = v_rechts_plus; vrm = v_rechts_minus; vlp = v_left_plus
    //vlm = v_left_minus; utlp = u_top_left_plus
    real_t utp = u->Cell(it) + u->Cell(it.Top());
    real_t vrp = this->Cell(it) + this->Cell(it.Right());
    real_t vrm = this->Cell(it) - this->Cell(it.Right());
    real_t utlp = u->Cell(it.Left()) + u->Cell(it.Top().Left());
    real_t vlp = this->Cell(it.Left()) + this->Cell(it);
    real_t vlm = this->Cell(it.Left()) - this->Cell(it);
    return ((utp*vrp - utlp*vlp) + alpha*(fabs(utp)*vrm - fabs(utlp)*vlm))/(4.0*this->_geom->Mesh()[0]);
}
/// Computes v*dv/dy with the donor cell method
real_t Grid::DC_vdv_y(const Iterator &it, const real_t &alpha) const{
        //vtp = v_top_plus; vtm = v_top_minus; vdp = v_down_plus; vdm = v_down_minus
    real_t vtp = this->Cell(it) + this->Cell(it.Top()); 
    real_t vtm = this->Cell(it) - this->Cell(it.Top());
    real_t vdp = this->Cell(it.Down()) + this->Cell(it);
    real_t vdm = this->Cell(it.Down()) - this->Cell(it);
    return ((vtp*vtp - vdp*vdp) + alpha*(fabs(vtp)*vtm - fabs(vdp)*vdm))/(4.0*this->_geom->Mesh()[1]);
}

/// Returns the maximal value of the grid
real_t Grid::Max() const{
    real_t temp = this->_data[0];
    for(index_t i = 0; i < this->_geom->Size()[0]*this->_geom->Size()[1]; i++){
        if(this->_data[i]>temp){
            temp = this->_data[i];
        }
    }
    return temp;
}
/// Returns the minimal value of the grid
real_t Grid::Min() const{
    real_t temp = this->_data[0];
    for(index_t i = 0; i < this->_geom->Size()[0]*this->_geom->Size()[1]; i++){
        if(this->_data[i]<temp){
            temp = this->_data[i];
        }
    }
return temp;
}
/// Returns the absolute maximal value
real_t Grid::AbsMax() const{
    real_t tempAbs = abs(_data[0]);
    for(index_t i = 0; i < _geom->Size()[0]*_geom->Size()[1]; i++){
        if(abs(_data[i]) > tempAbs){
            tempAbs = abs(_data[i]);
        }
    }
    return tempAbs;
}

/// Returns a pointer to the raw data
real_t *Grid::Data(){
    return _data;
}

// int main(int argc, char **argv) {
//     double a = (3)%(1/32);
//     double b = fmod(3.5,1/32);
//     std::cout << a << std::endl;
//     std::cout << b << std::endl;
// return 0;
// }